package Test;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Signinpass {
    public static void main(String[] args) {
        System.setProperty("webdriver.chrome.driver", "D:\\ChromeDriver\\chromedriver.exe");
        WebDriver driverr = new ChromeDriver();
        driverr.get("https://www.linkedin.com/");//open linkedin login page
        driverr.manage().window().maximize();
        driverr.findElement(By.xpath("//*[@id=\"session_key\"]")).sendKeys("abc@gmail.com");//enter email

        driverr.findElement(By.xpath("//*[@id=\"session_password\"]")).sendKeys("1234567@");//enter password
        //driverr.findElement(By.xpath("/html/body/main/section[1]/div[2]/form/a")).click();//for forget password click here

        driverr.findElement(By.xpath("/html/body/main/section[1]/div[2]/form/button")).click();//click to login

        //OR


        //signin with google
       // driverr.findElement(By.xpath("/html/body/main/section[1]/div[2]/div[1]/form/button")).click();
        driverr.quit();
    }
}