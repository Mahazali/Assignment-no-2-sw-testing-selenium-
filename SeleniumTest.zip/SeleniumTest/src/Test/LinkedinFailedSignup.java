package Test;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class LinkedinFailedSignup {
    public static void main(String[] args){
        System.setProperty("webdriver.chrome.driver","D:\\ChromeDriver\\chromedriver.exe");
        WebDriver driverr=new ChromeDriver();
        driverr.get("https://www.linkedin.com/signup/cold-join?trk=guest_homepage-basic_nav-header-join");//open linkedin signup page
        driverr.manage( ).window().maximize();
        driverr.findElement(By.xpath("//*[@id=\"email-address\"]")).sendKeys("abc@gmail.com");//write email
        driverr.findElement(By.xpath("//*[@id=\"password\"]")).sendKeys("1234567@");//write password


        driverr.findElement(By.xpath("/html/body/div/main/form/section/span/a[1]")).click();//click on user agreement
        // driverr.findElement(By.xpath("/html/body/div/main/form/section/span/a[2]")).click();//click on privacy policy
        //driverr.findElement(By.xpath("/html/body/div/main/form/section/span/a[3]")).click();//click on cookie policy
        driverr.findElement(By.xpath("//*[@id=\"join-form-submit\"]")).click();//clicking on join and agree


        //assumed that by clicking on join and agreeb it opens user agreement page

        //join with facebook
        //driverr.findElement(By.xpath("/html/body/div/main/form/section/div[3]/button")).click();

        //===========================================================================================//


        driverr.quit();


    }
}